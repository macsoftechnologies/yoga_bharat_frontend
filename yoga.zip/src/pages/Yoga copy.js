import React, { useState, useEffect } from "react";
import axios from "axios";
import Table from "../components/Table";
import Button from "../components/Button";
import Modal from "../components/Modal";
import CustomForm from "../components/CustomForm";

function Yoga() {
  const [open, setOpen] = useState(false);
  const [yogaList, setYogaList] = useState([]);

  // -------------------------------
  // 1. SAMPLE API GET
  // -------------------------------
  const fetchYogaList = async () => {
    try {
      const res = await axios.get("https://jsonplaceholder.typicode.com/users");

      // SAMPLE DATA CONVERSION
      const formatted = res.data.map((user) => ({
        name: user.name,
        category: "General",
        duration: "30 min",
        difficulty: "Beginner",
      }));

      setYogaList(formatted);
    } catch (err) {
      console.error("API Error:", err);
    }
  };

  // -------------------------------
  // 2. Call API once
  // -------------------------------
  useEffect(() => {
    fetchYogaList();
  }, []);

  // -------------------------------
  // 3. Table Columns
  // -------------------------------
  const columns = [
    { header: "Name", accessor: "name" },
    { header: "Category", accessor: "category" },
    { header: "Duration", accessor: "duration" },
    { header: "Difficulty", accessor: "difficulty" },
    { header: "Actions", accessor: "actions" },
  ];

  // -------------------------------
  // 4. Convert API → Table Data
  // -------------------------------
  const tableData = yogaList.map((item) => ({
    name: item.name,
    category: item.category,
    duration: item.duration,
    difficulty: item.difficulty,
    actions: (
      <div className="actions"> 
        <button className="view">View</button>
        <button className="edit">Edit</button>
        <button className="delete">Delete</button>
      </div>
    ),
  }));

  return (
    <div>
      {/* Header */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "20px",
          padding: "10px 20px",
        }}
      >
        <h2>YOGA LIST</h2>

        <Button text="+ Add Yoga" color="orange" onClick={() => setOpen(true)} />
      </div>

      {/* Table */}
      <Table columns={columns} data={tableData} rowsPerPage={5} />

      {/* Modal */}
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Add Yoga"
        size="lg"
        centered={true}
>
        <CustomForm onClose={() => setOpen(false)} />
      </Modal>
    </div>
  );
}

export default Yoga;
